<?php 
    require_once ('main-header.php');
?>
<body>
    
</body>
<?php 
    require_once ('main-footer.php');
?>
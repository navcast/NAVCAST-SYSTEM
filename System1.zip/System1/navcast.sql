-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 24, 2019 at 07:07 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `navcast`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `ID` varchar(100) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`ID`, `Username`, `Password`) VALUES
('1', 'Vincent', '123');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `studentId` varchar(200) NOT NULL,
  `studentName` varchar(100) NOT NULL,
  `permanentAddress` varchar(100) NOT NULL,
  `dateofBirth` varchar(100) NOT NULL,
  `contactNumber` int(30) NOT NULL,
  `positionRank` varchar(100) NOT NULL,
  `emailAddress` varchar(100) NOT NULL,
  `idPresented` varchar(100) NOT NULL,
  `contactPerson` varchar(100) NOT NULL,
  `contactPersonNumber` int(30) NOT NULL,
  `companyName` varchar(100) NOT NULL,
  `companyAddress` varchar(100) NOT NULL,
  `companyNumber` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`studentId`, `studentName`, `permanentAddress`, `dateofBirth`, `contactNumber`, `positionRank`, `emailAddress`, `idPresented`, `contactPerson`, `contactPersonNumber`, `companyName`, `companyAddress`, `companyNumber`) VALUES
('CLE-00027-21JAN2019-090549', 'Cleo  Miranda', 'Quezon City', 'August 21', 1234, 'Chiefmate', 'cleo@gmail.com', 'passport', 'Pam Alindogan', 12445, 'Marlow', 'Quirino', 123456),
('NOR-00019-21JAN2019-090702', 'Norlan Regalado', 'Yakal St', 'December 12 1994', 2147483647, 'cADET', '09959126906', 'ERKED', 'SKEDFMDK', 12445, 'Marlow', 'Quirino', 232354);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
